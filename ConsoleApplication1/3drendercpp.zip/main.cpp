
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <SDL.h>

#include "display.h"
#include "mesh.h"
#include "vect.h"
#include "swap.h"
#include "matrix.h"

long previous_frame_time = 0;

#define FPS 60
#define FRAME_TARGET_TIME (1000 / FPS)

CDisplay display;

bool is_running = false;



void setup() {
    display.setup();
       
}


int main(int argc, char** args) {
    is_running=display.init_window();//initialize_window();
    setup();    

    while (display.is_running) {
        display.process_input();

        SDL_RenderClear(display.renderer);
        display.draw_grid();

        int size = display.meshes.size();
        for (int count = 0; count < size; count++) {

          //  (&display.meshes[count])->rotation.x += 0.005;
            //  mesh->rotation.y += 0.005;
          //  (&display.meshes[count])->rotation.z += 0.005;

      

            display.updatemesh(&display.meshes[count]);
            display.updatepoints(&display.meshes[count]);   // Draw point cube

            display.rendertriangles();
            display.renderpoints();
        }
        display.render_color_buffer();
        display.clear_color_buffer(0xFF000000);
        SDL_RenderPresent(display.renderer);

    }
    display.destroy_window();

    return 0;
}

