#include <cstdlib>

#include "swap.h"
#include "triangle.h"
#include "display.h"



void CTriangle::init(CVec vertices[3]) {

    points[0]=vertices[0];
    points[1] = vertices[1];
    points[2] = vertices[2];
};


void CTriangle::init(CVec vertices[3], CTexture tex[3], int32_t col, upng_t* ptexture) {
    points[0] = vertices[0];
    points[1] = vertices[1];
    points[2] = vertices[2];

    texcoords[0]=tex[0];
    texcoords[1] = tex[1];
    texcoords[2] = tex[2];
    color = col;
    texture = ptexture;

};

CDisplay* display = nullptr;

///////////////////////////////////////////////////////////////////////////////
// Return the normal vector of a triangle face

   
///////////////////////////////////////////////////////////////////////////////
CVec CTriangle::get_triangle_normal(CVec vertices[3]) {
    // Get individual vectors from A, B, and C vertices to compute normal
    CVec vector_a = vertices[0]; /*   A   */
    CVec vector_b = vertices[1]; /*  / \  */
    CVec vector_c = vertices[2]; /* C---B */

    // Get the vector subtraction of B-A and C-A
    CVec vector_ab = vector_b- vector_a;
    CVec vector_ac = vector_c- vector_a;
    vector_ab.normalize();
    vector_ac.normalize();

    // Compute the face normal (using cross product to find perpendicular)
    CVec normal = vector_ab & vector_ac;
    normal.normalize();

    return normal;
}

///////////////////////////////////////////////////////////////////////////////
// Return the barycentric weights alpha, beta, and gamma for point p
///////////////////////////////////////////////////////////////////////////////
//
//          A
//         /|\
//        / | \
//       /  |  \
//      /  (p)  \
//     /  /   \  \
//    / /       \ \
//   //           \\
//  B ------------- C
//
///////////////////////////////////////////////////////////////////////////////
CVec barycentric_weights(CVec &a, CVec &b, CVec &c, CVec &p) {
    // Find the vectors between the vertices ABC and point p
    CVec ab = b - a;
    CVec bc = c - b;
    CVec ac = c - a;
    CVec ap = p - a;
    CVec bp = p - b;

    // Calcualte the area of the full triangle ABC using cross product (area of parallelogram)
    float area_triangle_abc = (ab.x * ac.y - ab.y * ac.x);

    // Weight alpha is the area of subtriangle BCP divided by the area of the full triangle ABC
    float alpha = (bc.x * bp.y - bp.x * bc.y) / area_triangle_abc;

    // Weight beta is the area of subtriangle ACP divided by the area of the full triangle ABC
    float beta = (ap.x * ac.y - ac.x * ap.y) / area_triangle_abc;

    // Weight gamma is easily found since barycentric cooordinates always add up to 1
    float gamma = 1 - alpha - beta;

    CVec weights = { alpha, beta, gamma };
    return weights;
}
