#include <math.h>
#include "vect.h"

///////////////////////////////////////////////////////////////////////////////
// Implementations of Vector 3 functions


///////////////////////////////////////////////////////////////////////////////


double CVec::length() {
    return sqrt(x * x + y * y + z * z);
}

void CVec::operator=(const CVec& b) {
    

    x = b.x;
    y = b.y;
    z = b.z;
    w = b.w;

    //CVec vec(x,y,z,w);

    //return vec;


}


CVec CVec::operator+(const CVec& b) {
    CVec vec(x, y, z, w);
    vec.x = this->x + b.x;
    vec.y = this->y + b.y;
    vec.z = this->z + b.z;
    vec.w = this->w + b.w;
   
    

    return vec;

   
}

CVec CVec::operator-(const CVec& b) {
    CVec vec(x, y, z, w);
    vec.x = this->x - b.x;
    vec.y = this->y - b.y;
    vec.z = this->z - b.z;
    vec.w = this->w - b.w;

    

    return vec;

}

CVec CVec::operator*(double factor) {
    CVec vec(x, y, z, w);
    vec.x = this->x * factor;
    vec.y = this->y * factor;
    vec.z = this->z * factor;
    vec.w = this->w * factor;

    

    return vec;

}

CVec CVec::operator/(double factor) {
    CVec vec(x, y, z, w);
    if (factor != 0.0) {
        vec.x = this->x / factor;
        vec.y = this->y / factor;
        vec.z = this->z / factor;
        vec.w = this->w / factor;

    }
    
    return vec;

}

CVec CVec::operator&(const CVec& b) {   //Cross Product
    CVec vec(x, y, z, w);
    vec.x = this->y * b.z - this->z * b.y;
    vec.y = this->z * b.x - this->x * b.z;
    vec.z = this->x * b.y - this->y * b.x;

   
    return vec; 
   
}

double CVec::operator^(const CVec& b) {   //Dot Product
    CVec vec;
    return (this->x * b.x) + (this->y * b.y) + (this->z * b.z);
}

void CVec::normalize() {
    double length = sqrt(x * x + y * y + z * z);
    if (length != 0.0) {
        x /= length;
        y /= length;
        z /= length;
    }
}

void CVec::rotate_x(double angle) {
    
        
    double yy = y * cos(angle) - z * sin(angle);
    double zz = y * sin(angle) + z * cos(angle);

    y = yy;
    z = zz;
    
}

void CVec::rotate_y(double angle) {
   
    double xx = x * cos(angle) - z * sin(angle);   
    double zz = x * sin(angle) + z * cos(angle);

    x = xx;
    z = zz;
       
}

void CVec::rotate_z(double angle) {
    
    double xx = x * cos(angle) - y * sin(angle);
    double yy = x * sin(angle) + y * cos(angle);

    x = xx;
    y = yy;
     
}

///////////////////////////////////////////////////////////////////////////////
// Implementations of Vector conversion functions
///////////////////////////////////////////////////////////////////////////////

/*
CVec  vec4_from_vec3(CVec v) {
    CVec  result = { v.x, v.y, v.z, 1.0 };
    return result;
}

CVec vec_from_vec4(CVec  v) {
    CVec result = { v.x, v.y, v.z };
    return result;
}

CVec  vec2_from_vec4(CVec  v) {
    CVec  result = { v.x, v.y };
    return result;
}
*/