#pragma once
#include <SDL.h>
#include "vector.h"

class CScene {
    bool is_running = false;
public:
    CScene() {
        is_running = true;
    }
    bool running() { return is_running; }
    bool process_input();
    void update();
    void render();
    void Loop();
};

