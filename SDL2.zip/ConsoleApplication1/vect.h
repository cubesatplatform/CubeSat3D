#pragma once

class CVec {

public:
	double x = 0.0, y = 0.0, z = 0.0, w = 1.0;   //0 as last one but when multiplying by 3x3 needs a 1 i believe
	////////////////////////////////////////////////////////////////////////////////
	// Vector 3 functions
	////////////////////////////////////////////////////////////////////////////////
	CVec() {}
	CVec(double a, double b, double c=0.0,double d=1.0) { Init(a, b, c,d); }
	void Init(double a, double b, double c, double d) { x = a; y = b; z = c; w = d; };
//	void clone(CVec v);
	double length();

	void operator=(const CVec& b);
	CVec operator+(const CVec& b);
	CVec operator-(const CVec& b);
	CVec operator*(double factor);
	CVec operator/(double factor);
	void operator+=(const CVec& b);
	void operator-=(const CVec& b);
	void operator*=(double factor);
	void operator/=(double factor);
	CVec operator&(const CVec& b);   //Cross Product
	double operator^(const CVec& b);  //Dot 
	/*
	void add(CVec b);
	void sub(CVec b);
	void mul(double factor);
	void div(double factor);
	void cross(CVec b);
	double dot(CVec b);
	*/
	void normalize();
	void rotate_x(double angle);
	void rotate_y(double angle);
	void rotate_z(double angle);

	////////////////////////////////////////////////////////////////////////////////
	// Vector conversion functions
	////////////////////////////////////////////////////////////////////////////////
	//CVec  vec4_from_vec3(CVec v);
	//CVec vec3_from_vec4(CVec  v);
	//CVec  vec2_from_vec4(CVec  v);
};