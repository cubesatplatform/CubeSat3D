#pragma once

#include <stdint.h>
#include "texture.h"
#include "vect.h"
#include "upng.h"


struct CFace {
    int a;
    int b;
    int c;
    CTexture a_uv;
    CTexture b_uv;
    CTexture c_uv;
    uint32_t color;
    CFace(int aa, int bb, int cc) { a = aa; b = bb; c = cc; }
    CFace(int aa, int bb, int cc, CTexture aa_uv, CTexture bb_uv, CTexture cc_uv, uint32_t ccolor) { a = aa; b = bb; c = cc; a_uv = aa_uv; b_uv = bb_uv; c_uv = cc_uv; color = ccolor; }
};




CVec barycentric_weights(CVec &a, CVec &b, CVec &c, CVec &p);

class CTriangle {
  
public:
    CVec points[3];
    CTexture texcoords[3];
    uint32_t color=0xCCCCCC;
    upng_t* texture=NULL;



    CTriangle() {};
    void init(CVec vertices[3]);
    void init(CVec vertices[3], CTexture tex[3], int32_t col, upng_t* ptexture);
    CVec get_triangle_normal(CVec vertices[3]);
};