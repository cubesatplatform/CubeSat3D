#pragma once

class CTexture {
public:
    float u;
    float v;
    CTexture() { u = 0.0; v = 0.0; }
    CTexture(float a, float b) { Init(a, b); }
    void Init(float a, float b) { u = a; v = b; }
    void operator=(const CTexture& b) {
        
        u = b.u;
        v = b.v;
        //CTexture tex(u,v);
        //return tex;
    };
};