#include "scene.h"
#include "display.h"

CDisplay display;

bool CScene::process_input(void) {
    bool is_running = true;
    SDL_Event event;
    SDL_PollEvent(&event);

    switch (event.type) {
    case SDL_QUIT:
        is_running = false;
        break;
    case SDL_KEYDOWN:
        if (event.key.keysym.sym == SDLK_ESCAPE)
            is_running = false;
        break;
    }
    return(is_running);
}


void CScene::update(void) {
    for (int i = 0; i < N_POINTS; i++) {
        CVec point = cube_points[i];

        // Project the current point
        CVec  projected_point = project(point);

        // Save the projected 2D vector in the array of projected points
        projected_points[i] = projected_point;
    }
}

void CScene::render(void) {
    display.draw_grid();

    // Loop all projected points and render them
    for (int i = 0; i < N_POINTS; i++) {
        CVec  projected_point = projected_points[i];
        display.draw_rect(
            projected_point.x + (window_width / 2),
            projected_point.y + (window_height / 2),
            4,
            4,
            0xFFFFFF00
        );
    }

    display.render_color_buffer();

    display.clear_color_buffer(0xFF000000);

    SDL_RenderPresent(renderer);
}

void CScene::Loop(void) {
    process_input();
    update();
    render();
}

